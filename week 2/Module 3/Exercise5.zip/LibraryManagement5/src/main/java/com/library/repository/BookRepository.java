package com.library.repository;

public interface BookRepository {
    // Method definitions
}

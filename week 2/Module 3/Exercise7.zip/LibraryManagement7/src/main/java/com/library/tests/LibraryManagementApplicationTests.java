package com.library.tests;
	import com.library.service.BookService;
	import com.library.repository.BookRepository;
	import org.junit.jupiter.api.Test;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.boot.test.context.SpringBootTest;

	import static org.assertj.core.api.Assertions.assertThat;

	@SpringBootTest
	public class LibraryManagementApplicationTests {

	    @Autowired
	    private BookService bookService;

	    @Autowired
	    private BookRepository bookRepository;

	    @Test
	    public void contextLoads() {
	        // Check if BookService and BookRepository beans are not null
	        assertThat(bookService).isNotNull();
	        assertThat(bookRepository).isNotNull();

	        // Check if BookService has the correct BookRepository injected
	        // Using reflection to verify setter injection (if needed)
	        try {
	            BookRepository injectedRepository = (BookRepository) 
	                bookService.getClass().getDeclaredField("bookRepository").get(bookService);
	            assertThat(injectedRepository).isEqualTo(bookRepository);
	        } catch (Exception e) {
	            e.printStackTrace();
	            assertThat(false).isTrue(); // Fail the test if reflection fails
	        }
	    }
	}



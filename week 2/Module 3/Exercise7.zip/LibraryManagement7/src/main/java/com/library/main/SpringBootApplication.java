package com.library.main;

public @interface SpringBootApplication {

}

package com.library.tests;

public @interface SpringBootTest {

}

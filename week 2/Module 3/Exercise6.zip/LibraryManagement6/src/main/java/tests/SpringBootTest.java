package tests;

public @interface SpringBootTest {

}

package tests;

import com.library.service.BookService;
import com.library.repository.BookRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class LibraryManagementApplicationTests {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookRepository bookRepository;

    @Test
    public void contextLoads() {
        assertThat(bookService).isNotNull();
        assertThat(bookRepository).isNotNull();
    }

	private Object assertThat(BookService bookService2) {
		// TODO Auto-generated method stub
		return null;
	}

	private Object assertThat(BookRepository bookRepository2) {
		// TODO Auto-generated method stub
		return null;
	}
}

package tests;

public @interface Autowired {

}

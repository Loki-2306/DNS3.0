package com.library.main;

public interface SpringApplication {

	static void run(Class<LibraryManagementApplication> class1, String[] args) {
		// TODO Auto-generated method stub
		
	}

}

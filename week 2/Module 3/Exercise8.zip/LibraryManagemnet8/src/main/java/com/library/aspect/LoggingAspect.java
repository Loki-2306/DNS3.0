
	package com.library.aspect;

	import org.aspectj.lang.JoinPoint;
	import org.aspectj.lang.annotation.Aspect;
	import org.aspectj.lang.annotation.Before;
	import org.aspectj.lang.annotation.After;
	import org.springframework.stereotype.Component;
	public class LoggingAspect {

	    // Advice to log before the execution of methods in service package
	    @Before("execution(* com.library.service..*(..))")
	    public void logBefore(JoinPoint joinPoint) {
	        System.out.println("Entering method: " + joinPoint.getSignature().toShortString());
	    }

	    // Advice to log after the execution of methods in service package
	    @After("execution(* com.library.service..*(..))")
	    public void logAfter(JoinPoint joinPoint) {
	        System.out.println("Exiting method: " + joinPoint.getSignature().toShortString());
	    }
	}



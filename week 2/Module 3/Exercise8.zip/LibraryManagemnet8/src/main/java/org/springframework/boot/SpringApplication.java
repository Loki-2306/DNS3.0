package org.springframework.boot;

public @interface SpringApplication {

}

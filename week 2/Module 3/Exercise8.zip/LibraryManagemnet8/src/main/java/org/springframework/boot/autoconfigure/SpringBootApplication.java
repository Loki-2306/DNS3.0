package org.springframework.boot.autoconfigure;

public @interface SpringBootApplication {

}

package cognizant;
	public class SortingTest {
	    public static void main(String[] args) {
	        Order[] orders = {
	            new Order("003", "Lokesh", 150.75),
	            new Order("001", "Shoaib", 200.50),
	            new Order("002", "Hiruthik", 120.00),
	            new Order("004", "Varun", 175.25)
	        };

	        System.out.println("Before Bubble Sort:");
	        for (Order order : orders) {
	            System.out.println(order);
	        }

	        SortingUtil.bubbleSort(orders);

	        System.out.println("\nAfter Bubble Sort:");
	        for (Order order : orders) {
	            System.out.println(order);
	        }

	        orders = new Order[]{
	            new Order("003", "Lokesh", 150.75),
	            new Order("001", "Shoaib", 200.50),
	            new Order("002", "Hiruthik", 120.00),
	            new Order("004", "Varun", 175.25)
	        };

	        System.out.println("\nBefore Quick Sort:");
	        for (Order order : orders) {
	            System.out.println(order);
	        }

	        SortingUtil.quickSort(orders, 0, orders.length - 1);

	        System.out.println("\nAfter Quick Sort:");
	        for (Order order : orders) {
	            System.out.println(order);
	        }
	    }
	}



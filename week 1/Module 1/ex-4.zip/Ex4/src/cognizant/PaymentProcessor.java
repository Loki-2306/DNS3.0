package cognizant;
	public interface PaymentProcessor {
		void processPayment(double amount);
	}


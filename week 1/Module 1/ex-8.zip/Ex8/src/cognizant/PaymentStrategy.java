package cognizant;

public interface PaymentStrategy {
	void pay(double amount);
}

package cognizant;

public interface Command {
	void execute();
}

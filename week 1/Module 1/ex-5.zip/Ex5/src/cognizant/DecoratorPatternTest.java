package cognizant;

public class DecoratorPatternTest {
	public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        emailNotifier.send("Hello, this is a basic email notification!");

        System.out.println("\nAdding SMS Notification:");
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        smsNotifier.send("Hello, this is an email with SMS notification!");
    }
}

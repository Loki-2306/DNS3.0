package cognizant;
	public class SMSNotifierDecorator implements Notifier {
		public SMSNotifierDecorator(Notifier notifier) {
	        super();
	    }

	    public void send(String message) {
	        
	        sendSMS(message);
	    }
	    private void sendSMS(String message) {
	        System.out.println("Sending SMS: " + message);
	    }
	}


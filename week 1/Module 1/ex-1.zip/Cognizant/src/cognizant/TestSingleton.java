package cognizant;

public class TestSingleton {

}

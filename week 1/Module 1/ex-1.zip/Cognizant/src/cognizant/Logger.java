package cognizant;

public class Logger {

}

package cognizant;

	public class ConcreteExcelDocument extends ExcelDocument {
	   
	    public void open() {
	        System.out.println("Opening a specific Excel document.");
	    }

}

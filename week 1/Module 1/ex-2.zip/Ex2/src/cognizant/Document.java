package cognizant;
	public interface Document {
		void open();
	}

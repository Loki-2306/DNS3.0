package cognizant;

public interface Image {
	void display();

}
